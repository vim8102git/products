import { Injectable } from '@angular/core';
const TOKEN= 'TOKEN';

@Injectable({
  providedIn: 'root'
})
export class TokenService {

  setToken(key: string, token: string): void {
    sessionStorage.setItem(key, token);
  }

  isOnLogin() {
    return sessionStorage.getItem('isOnLogin') === 'yes';
  }

  isOnDashboard() {
    return sessionStorage.getItem('isOnDashboard') === 'yes';
  }
}

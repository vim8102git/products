import { Injectable } from '@angular/core';
import { CanActivate, CanDeactivate, 
  ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import {TokenService} from './auth.token.service';
import { LoginComponent } from './login/containers/login/login.component';

@Injectable()
export class AuthGuard implements CanDeactivate<LoginComponent>, CanActivate {
  constructor(private customerService: TokenService, private router: Router) {
  }

  canDeactivate(component: LoginComponent){
    console.log(component);
    return true;
  }
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot) {
      const redirectUrl = route['_routerState']['url'];
      if(this.customerService.isOnLogin){
        return true;
      }
      return false;
    }
}

import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

import { ServiceWorkerModule } from '@angular/service-worker';


import { environment } from '../environments/environment';
import { AppComponent } from './app.component';


//Custom modules can be declared here
import { LoginModule } from './login/login.module';
import { ChannelsModule } from './channels/channels.module';
import { ReviewModule } from './review/review.module';

//Custom components can be declared here
import { LoginComponent } from './login/containers/login/login.component';
import { ReviewComponent}  from './review/components/review/review.component';
import { ChannelsComponent } from './channels/containers/channels/channels.component';
import { RouterModule, Routes } from '@angular/router';
import { NotFoundComponent } from './notFound.component';

//Custom services can be declared here


import { AppHeaderComponent } from './components/app-header/app-header.componet';

import { AuthModule } from '../auth/auth.module';
import { Store } from '../store';
import {AuthGuard} from '../auth/shared/guards/auth.guard';
const routes:Routes = [
  {
    path:'',pathMatch: 'full', redirectTo: 'auth'
  },
  {
    path: 'dashboard', component: ChannelsComponent, canActivate: [AuthGuard]
  },
  {
    path: 'review', component: ReviewComponent, canActivate: [AuthGuard]
  },
  {
    path: '**', component: NotFoundComponent
  }
];

@NgModule({
  declarations: [
    AppComponent,
    NotFoundComponent,
    AppHeaderComponent
  ],
  imports: [
    BrowserModule,
    //ServiceWorkerModule.register('/ngsw-worker.js', { enabled: environment.production }),
    HttpClientModule,
    FormsModule,
    //Custom modules can be injected here
    ChannelsModule,
    ReviewModule,
    //LoginModule,

    RouterModule.forRoot(routes),
    AuthModule
  ],
  providers: [
    Store,
    AuthGuard
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
/*
// Initialize Firebase
var config = {
  apiKey: "AIzaSyCcvZdJad5a4TwnVmLCOtvTEOdOW2CIi6o",
  authDomain: "manage-channels.firebaseapp.com",
  databaseURL: "https://manage-channels.firebaseio.com",
  projectId: "manage-channels",
  storageBucket: "manage-channels.appspot.com",
  messagingSenderId: "882539097706"
};*/

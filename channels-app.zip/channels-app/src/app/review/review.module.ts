import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

import { ReviewComponent } from './components/review/review.component';

@NgModule({
    imports: [
        CommonModule,
        RouterModule
    ],
    declarations: [
        ReviewComponent
    ],
    exports: [
        ReviewComponent
    ]
})

export class ReviewModule{

}
import { Component } from '@angular/core';

@Component({
    selector: 'not-found',
    template: `
        Not found, <a routerLink="/">Go home</a>?
    `
})
export class NotFoundComponent{

}
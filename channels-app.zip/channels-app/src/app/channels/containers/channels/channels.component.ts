import { Component, OnInit } from '@angular/core';
import { Channel } from '../../models/channel.interface';
import { ChannelsService } from '../../channels.service';
import { TokenService } from '../../../auth.token.service';
import { Router } from '@angular/router';

import { Store } from '../../../../store';

@Component({
    selector: 'channels',
    styleUrls: ['channels.component.scss'],
    template: `
        <button class="continue" (click)="manage()">
            Manage my channels
        </button>

        <div class="container" *ngIf="showChannels">
            <channel
                *ngFor="let channel of channels;"
                [channel]="channel"
                [showPrice]="true"
                (addOrRemove)="handleAddOrRemove($event)"
                (countValue) = "displayCount($event)">
            </channel>
        </div>
        <button [ngClass]="{'clicked': clicked}"  class="continue" (click)="addToCart()">
            Proceed
        </button>
        <p> You have selected {{count}} channels </p>

        <p>You will pay {{price | currency}}</p>
    `
})

export class ChannelsComponent implements OnInit{
    channels: Channel[];
    
    records: any = [];
    clicked: boolean = false;
    addedChannels: any = [];
    count:number = 0;
    selectedChannelIdList:any[];
    price: number = 0;
    showChannels: boolean = false;
    constructor(private router: Router,private store:Store,private channelsService: ChannelsService, private tokenService: TokenService){
      this.count = 0;
      this.selectedChannelIdList = [];
    }

    ngOnInit(){
        this.tokenService.setToken('isOnDashboard', 'yes');
        let selectedChannels = this.channelsService.getSelectedChannels();
        if(selectedChannels){
            this.count = selectedChannels.length;
            selectedChannels.forEach((channel) => {
                this.price+=+channel.channelPrice;
            })
        }
    }
    
    manage(){
        if(!this.showChannels){
            if(!this.channels){
                this.channelsService.getAllChannels().subscribe((data: any) =>{
                    this.records = data.channelList.records;
                    let channelList = [];
                    this.records.forEach((record)=> channelList.push(record.attributes))
                    this.channelsService.cacheChannels(channelList);
                    let selectedChannels = this.channelsService.getSelectedChannels();
                    let newChannelList = channelList.map((channel) => {
                        let a = selectedChannels.find((value) => 
                        value.channelId === channel.channelId)
                        if(a){
                            return {...channel, selected:true}
                        }else{
                            return channel;
                        }
                    })
                    this.channels = newChannelList;
                })    
            }else{ 
                
                this.channels = this.channelsService.getCachedChannels(); }
            this.showChannels = true;
        }else{
            this.showChannels = false;
        } 
    }

    addToCart(){
        this.clicked = true;
        setTimeout(()=>{this.clicked = false;},2000);
        console.log("selected Channels",this.selectedChannelIdList);
        setTimeout(()=>{this.clicked = false;},2000);
        console.log("selected Channels",this.selectedChannelIdList);
        console.log(this.addedChannels);
        this.channelsService.setSelectedChannels(this.addedChannels);
        this.router.navigate(['/review']);
    }

    handleAddOrRemove(event) {
        console.log(event);
        let i = this.channelsService.getSelectedChannels()
        .findIndex((chanel) => chanel.channelId === event.channelId);
        if( i > -1){
            this.price-=+event.channelPrice;
            --this.count;
            this.channelsService.removeChannel(event.channelId);   
        }else{
            console.log('else');
            let index = this.addedChannels.findIndex((chanel) => chanel.channelId === event.channelId);
            if(index > -1){
                this.addedChannels.splice(index,1);
                this.price-=+event.channelPrice;
                --this.count;
            }else{
                this.addedChannels.push(event);
                this.price+=+event.channelPrice;
                ++this.count;
            }
        }
        
        if(!(this.selectedChannelIdList.some(channelList => channelList === event.channelId))) {
            this.selectedChannelIdList.push(event.channelId);
        } else {
          let index = this.selectedChannelIdList.findIndex(channelList => channelList === event.channelId);
          this.selectedChannelIdList.splice(index, 1);
        }
    }

    displayCount(count){
        this.count = this.count + count;
    }
}

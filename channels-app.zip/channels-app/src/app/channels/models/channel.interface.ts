export interface Channel{
    cliccId: string,
    nameEn: string,
    genreEn: string,
    channelId: string,
    descriptionEn: string,
    channelPrice: string,
    priceFrequency: string
}
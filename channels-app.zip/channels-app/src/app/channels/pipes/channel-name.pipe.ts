import { Pipe, PipeTransform } from '@angular/core';

@Pipe({name: 'setSameHeight'})
export class SetSameHeightPipe implements PipeTransform{
    transform(value: string, wordWise: boolean, max:number, tail:string){
        if (!value) return;
        if (!max) return value;
        if (value.length <= max) return value;

        value = value.substr(0, max);
        if (wordWise) {
            var lastSpace = value.lastIndexOf(' ');
            if (lastSpace !== -1) {
                if (value.charAt(lastSpace-1) === '.' || value.charAt(lastSpace-1) === ',') {
                    lastSpace = lastSpace - 1;
                }
                value = value.substr(0, lastSpace);
            }
        }

        return value + (tail || '…');
    }
}
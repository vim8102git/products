import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';

import { AuthFormModule } from './shared/shared.module';

import { AngularFireModule, FirebaseAppConfig } from '@angular/fire';
import { AngularFireAuthModule } from '@angular/fire/auth';
import { AngularFireDatabaseModule } from '@angular/fire/database';

export const ROUTES: Routes = [
    {
        path: 'auth',
        children: [
            {path: '', pathMatch: 'full', redirectTo: 'login'},
            {path: 'login', loadChildren: './login/login.module#LoginModule'},
            {path: 'register', loadChildren: './register/register.module#RegisterModule'},
        ]
    }

];

export const firebaseConfig : FirebaseAppConfig = {
    apiKey: "AIzaSyCcvZdJad5a4TwnVmLCOtvTEOdOW2CIi6o",
    authDomain: "manage-channels.firebaseapp.com",
    databaseURL: "https://manage-channels.firebaseio.com",
    projectId: "manage-channels",
    storageBucket: "manage-channels.appspot.com",
    messagingSenderId: "882539097706"
};

@NgModule({
    imports: [
        CommonModule,
        RouterModule.forChild(ROUTES),
        AngularFireModule.initializeApp(firebaseConfig),
        AngularFireAuthModule,
        AngularFireDatabaseModule,
        AuthFormModule.forRoot()
    ]
})
export class AuthModule{

}
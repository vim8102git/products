import { Component, OnInit } from '@angular/core';
import { Channel } from '../../models/channel.interface';
import { ChannelsService } from '../../channels.service';
import { Router } from '@angular/router';

import { Store } from '../../../../store';

@Component({
    selector: 'channels',
    styleUrls: ['channels.component.scss'],
    template: `
        <button class="continue" (click)="manage()">
            Manage my channels
        </button>

        <div class="container" *ngIf="showChannels">
            <channel
                *ngFor="let channel of channels;"
                [channel]="channel"
                [showPrice]="true"
                (addOrRemove)="handleAddOrRemove($event)"
                (countValue) = "displayCount($event)">
            </channel>
            <button [ngClass]="{'clicked': clicked}"  class="continue" (click)="addToCart()">
                Proceed
            </button>
            <p>You have selected {{count}} channels </p>
            <p>You will pay {{price | currency}}</p>
        </div>
        
    `
})

export class ChannelsComponent implements OnInit{
    channels: Channel[];
    
    records: any = [];
    clicked: boolean = false;
    addedChannels: any = [];
    count:number = 0;
    selectedChannelIdList:any[];
    price: number = 0;
    showChannels: boolean = false;
    constructor(private router: Router,private store:Store,private channelsService: ChannelsService){
      this.selectedChannelIdList = [];
    }

    ngOnInit(){
        let selectedChannels = this.channelsService.getSelectedChannels();
        this.addedChannels = this.channelsService.getSelectedChannels();
        if(selectedChannels){
            this.count = selectedChannels.length;
            selectedChannels.forEach((channel) => {
                this.price+=+channel.channelPrice;
            })
        }
    }
    
    manage(){
        let addSelectedFlag = (channels) => {
            let selectedChannels = this.channelsService.getSelectedChannels();
            return channels.map((channel) => {
                if(this.channelsService.getSelectedChannels()
                    .find((selectedChannel) => 
                    selectedChannel.channelId === channel.channelId)){
                        return { ...channel, selected: true };
                }else{
                    return channel;
                }
            })
        }
        if(!this.showChannels){
            if(!this.channels){
                this.channelsService.getAllChannels().subscribe((data: any) =>{
                    this.records = data.channelList.records;
                    let channelList = [];
                    this.records.forEach((record)=> channelList.push(record.attributes))
                    this.channelsService.cacheChannels(channelList);
                    this.channels = addSelectedFlag(channelList);
                })    
            }else{ 
                this.channels = addSelectedFlag(this.channelsService.getCachedChannels());
            }
            this.showChannels = true;
        }else{
            this.showChannels = false;
        } 
    }

    addToCart(){
        this.clicked = true;
        this.channelsService.setSelectedChannels(this.addedChannels);
        setTimeout(()=>{
            this.clicked = false;
            this.router.navigate(['/review']);     
        },1000);
        
    }

    handleAddOrRemove(event) {
        let i = this.channelsService.getSelectedChannels()
        .findIndex((chanel) => chanel.channelId === event.channelId);
        if( i > -1){
            this.price-=+event.channelPrice;
            --this.count;
            this.channelsService.removeChannel(event.channelId);   
        }else{
            console.log('else');
            let index = this.addedChannels.findIndex((chanel) => chanel.channelId === event.channelId);
            if(index > -1){
                this.addedChannels.splice(index,1);
                this.price-=+event.channelPrice;
                --this.count;
            }else{
                this.addedChannels.push(event);
                this.price+=+event.channelPrice;
                ++this.count;
            }
        }
    }
}

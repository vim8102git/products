import { Component, OnInit } from '@angular/core';
import { Channel } from '../../models/channel.interface';
import { ChannelsService } from '../../channels.service';

@Component({
    selector: 'channels',
    styleUrls: ['channels.component.scss'],
    template: `
        <div class="container">
            <channel
                *ngFor="let channel of channels;"
                [channel]="channel"
                [showPrice]="true"
                (addOrRemove)="handleAddOrRemove($event)"
                (countValue) = "displayCount($event)">
            </channel>
        </div>
        <button [ngClass]="{'clicked': clicked}"  class="continue" (click)="addToCart()">
            Proceed
        </button>
        <p> You have selected {{count}} channels </p>
        <p>You will pay {{price | currency}}</p>
    `
})

export class ChannelsComponent implements OnInit{
    channels: Channel[];
    clicked: boolean = false;
    addedChannels: any = []; 
    count:number =0;
    price: number = 0;
    constructor(private channelsService: ChannelsService){this.count = 0;}

    ngOnInit(){
        this.channelsService.getAllChannels().subscribe((data: any) =>{
            this.channels = data.channels;
        })
    }

    addToCart(){
        this.clicked = true;
        setTimeout(()=>{this.clicked = false;},2000);
    }

    handleAddOrRemove(event){
        let index = this.addedChannels.findIndex((chanel) => chanel === event);
        if(index > -1){
            this.addedChannels.splice(index,1);
            this.price-=+event.channelPrice;
            --this.count;
        }else{
            this.addedChannels.push(event);
            this.price+=+event.channelPrice;
            ++this.count;
        }
    }

    displayCount(count){
        this.count = this.count + count;
    }
}

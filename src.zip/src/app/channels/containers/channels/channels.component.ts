import { Component, OnInit } from '@angular/core';
import { Channel } from '../../models/channel.interface';
import { ChannelsService } from '../../channels.service';

@Component({
    selector: 'channels',
    styleUrls: ['channels.component.scss'],
    template: `
        <div class="container">
            <channel 
                *ngFor="let channel of channels;"
                [channel]="channel"
                (addOrRemove)="handleAddOrRemove($event)">
            </channel>
        </div>
        
    `
})

export class ChannelsComponent implements OnInit{
    channels: Channel[];
    channelId;
    addedChannelSkus;
    constructor(private channelsService: ChannelsService){}
    ngOnInit(){
        this.channelsService.getAllChannels().subscribe((data: any) =>{
            this.channels = data.channels;console.log(data);
        })
    }
    handleAddOrRemove(event){
        console.log("Added");

    }
}
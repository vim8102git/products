import { Component, OnInit } from '@angular/core';
import { Channel } from '../../models/channel.interface';
import { ChannelsService } from '../../channels.service';

@Component({
    selector: 'channels',
    styleUrls: ['channels.component.scss'],
    template: `
        <div class="container">
            <channel
                *ngFor="let channel of channels;"
                [channel]="channel"
                (addOrRemove)="handleAddOrRemove($event)"
                (countValue) = "displayCount($event)">
            </channel>
        </div>
        <button [ngClass]="{'clicked': clicked}"  class="continue" (click)="addToCart()">
            Proceed
        </button>
        <p> You have selected {{count}} channels </p>
    `
})

export class ChannelsComponent implements OnInit{
    channels: Channel[];
    clicked: boolean = false;
    count:number;
    constructor(private channelsService: ChannelsService){this.count = 0;}

    ngOnInit(){
        this.channelsService.getAllChannels().subscribe((data: any) =>{
            this.channels = data.channels;
        })
    }

    addToCart(){
        this.clicked = true;
        setTimeout(()=>{this.clicked = false;},2000);
    }

    handleAddOrRemove(event){
        console.log("Added channels", event);
    }

    displayCount(count){
        this.count = this.count + count;
    }
}

import { Component, OnInit } from '@angular/core';
import { Channel } from '../../models/channel.interface';
import { ChannelsService } from '../../channels.service';

@Component({
    selector: 'channels',
    styleUrls: ['channels.component.scss'],
    template: `
        <button class="continue" (click)="manage()">
            Manage my channels
        </button>

        <div class="container" *ngIf="showChannels">
            <channel
                *ngFor="let channel of channels;"
                [channel]="channel"
                [showPrice]="true"
                (addOrRemove)="handleAddOrRemove($event)"
                (countValue) = "displayCount($event)">
            </channel>
        </div>
        <button [ngClass]="{'clicked': clicked}"  class="continue" (click)="addToCart()">
            Proceed
        </button>
        <p> You have selected {{count}} channels </p>

        <p>You will pay {{price | currency}}</p>
    `
})

export class ChannelsComponent implements OnInit{
    channels: Channel[];
    
    records: any = [];
    clicked: boolean = false;
    addedChannels: any = [];
    count:number = 0;
    selectedChannelIdList:any[];
    price: number = 0;
    showChannels: boolean = false;
    constructor(private channelsService: ChannelsService){
      this.count = 0;
      this.selectedChannelIdList = [];
    }

    ngOnInit(){}
    
    manage(){
        if(!this.showChannels){
            if(!this.channels){
                this.channelsService.getAllChannels().subscribe((data: any) =>{
                    this.records = data.channelList.records;
                    let channelList = [];
                    this.records.forEach((record)=> channelList.push(record.attributes))
                    this.channelsService.cacheChannels(channelList);
                    this.channels = channelList;
                })    
            }else{ this.channels = this.channelsService.getCachedChannels(); }
            this.showChannels = true;
        }else{
            this.showChannels = false;
        } 
    }

    addToCart(){
        this.clicked = true;
        setTimeout(()=>{this.clicked = false;},2000);
        console.log("selected Channels",this.selectedChannelIdList);
        setTimeout(()=>{this.clicked = false;},2000);
        console.log("selected Channels",this.selectedChannelIdList);
    }

    handleAddOrRemove(event) {
        let index = this.addedChannels.findIndex((chanel) => chanel === event);
        if(index > -1){
            this.addedChannels.splice(index,1);
            this.price-=+event.channelPrice;
            --this.count;
        }else{
            this.addedChannels.push(event);
            this.price+=+event.channelPrice;
            ++this.count;
        }
        if(!(this.selectedChannelIdList.some(channelList => channelList === event.channelId))) {
            this.selectedChannelIdList.push(event.channelId);
        } else {
          let index = this.selectedChannelIdList.findIndex(channelList => channelList === event.channelId);
          this.selectedChannelIdList.splice(index, 1);
        }
    }

    displayCount(count){
        this.count = this.count + count;
    }
}

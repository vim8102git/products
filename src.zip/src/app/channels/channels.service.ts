import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Channel } from './models/channel.interface';


const CHANNELS_API: string = '/api/channels';

@Injectable()
export class ChannelsService{
    constructor(private http: HttpClient){}
    cachedChannels: any;

    /*Cache channels response to reuse it*/ 
    cacheChannels(channelList): any{
        this.cachedChannels = channelList ? channelList : [];
    }
    getCachedChannels(){
        return this.cachedChannels ? this.cachedChannels : [];
        
    }

    getAllChannels(): Observable<any>{
        return this.http.get(CHANNELS_API);
    }
}
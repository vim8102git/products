import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Channel } from './models/channel.interface';


const CHANNELS_API: string = '/api/channels';

@Injectable()
export class ChannelsService{
    constructor(private http: HttpClient){}
    cachedChannels: any;
    addedChannels: any;

    /*Cache channels response to reuse it*/ 
    cacheChannels(channelList): any{
        this.cachedChannels = channelList ? channelList : [];
    }
    getCachedChannels(){
        return this.cachedChannels ? this.cachedChannels : [];
        
    }
    removeChannel(sku){
        let index = this.addedChannels.findIndex((chanel) => 
        chanel.channelId === sku);
        if(index > -1){
            this.addedChannels.splice(index,1);
        }
    }

    setSelectedChannels(channels){
        this.addedChannels = channels ? channels: [];
    }

    getSelectedChannels(){
        return this.addedChannels ? this.addedChannels : [];
    }

    getAllChannels(): Observable<any>{
        return this.http.get(CHANNELS_API);
    }
}
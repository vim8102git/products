import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';

import { ChannelsComponent } from './containers/channels/channels.component';
import { ChannelComponent } from './components/channel/channel.component';
import { ChannelsService} from './channels.service';
import { SetSameHeightPipe } from './pipes/channel-name.pipe';

@NgModule({
    declarations: [
        ChannelsComponent,
        ChannelComponent,
        SetSameHeightPipe
    ],
    imports: [
        CommonModule,
        HttpClientModule
    ],
    exports: [
        ChannelsComponent
    ],
    providers:[
        ChannelsService
    ]
})
export class ChannelsModule{

}
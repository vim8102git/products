import { Component, Input, Output, EventEmitter } from '@angular/core';

import { Channel } from '../../models/channel.interface';

@Component({
    selector: 'channel',
    styleUrls: ['channel.component.scss'],
    template: `
    <div class="channel">
        <button [ngClass]="{'selected': toggle}" (click)="handleClick()" 
        class="channel-logo"
        [name]="channel.cliccId"></button>
        <div *ngIf="toggle" class="check-wrap"></div>
        <div class="channel-name">{{channel.nameEn}}</div>
    </div>`
})

export class ChannelComponent{

    toggle: boolean;
    @Input()
    channel: Channel;

    @Output()
    addOrRemove: EventEmitter<any> = new EventEmitter();
    constructor(){}

    handleClick(){
        this.addOrRemove.emit(this.channel);
        this.toggle = !this.toggle;
    }
}
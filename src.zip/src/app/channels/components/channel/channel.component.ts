import { Component, Input, Output, EventEmitter } from '@angular/core';

import { Channel } from '../../models/channel.interface';

@Component({
    selector: 'channel',
    styleUrls: ['channel.component.scss'],
    template: `
    <div class="channel">
        <button [title]="channel.nameEn" [ngClass]="{'selected': toggle}" (click)="handleClick()"
        class="channel-logo"
        [name]="channel.cliccId"></button>
        <div *ngIf="toggle" class="check-wrap"></div>
        <div class="channel-price" *ngIf="showPrice">
        {{channel.channelPrice | currency}}/mo</div>
        <div class="channel-name">{{channel.nameEn | setSameHeight:true:10: '...'}}</div>
    </div>`
})

export class ChannelComponent{

    count: number;
    toggle: boolean;
    @Input()
    channel: Channel;

    @Input()
    showPrice: boolean;

    @Output() addOrRemove: EventEmitter<any> = new EventEmitter();
    @Output() countValue: EventEmitter<any> = new EventEmitter();
    constructor(){this.count = 0;}

    handleClick(){
        this.addOrRemove.emit(this.channel);
        this.toggle = !this.toggle;
        //this.toggle ? this.count = 1 : this.count = -1;
        //this.countValue.emit(this.count);
    }
}

import {Component} from '@angular/core';
import {TokenService} from '../../../auth.token.service';
import {Router} from '@angular/router';
import {LoginService} from '../../login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html'
})
export class LoginComponent{

  email = 'aritrya@solaris';
  password = 'solaris';

  constructor(private api: LoginService, private customer: TokenService, private router: Router) {
  }

  ngOnInit(){
    
  }


  tryLogin() {
    this.api.login(
      this.email,
      this.password
    )
      .subscribe(
        result => {
          if (result.token) {
            //this.customer.setToken('isLoggedIn', 'yes');
            this.customer.setToken('isOnLogin', 'yes'); 
          }
        },
        result => {
          alert(result.error.error);
        });
  }

}

import {Component} from '@angular/core';
import {ApiService} from '../services/api.service';
import {Router} from '@angular/router';
import {CustomerService} from '../services/customer.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent{

  email = 'aritrya@solaris';
  password = 'solaris';

  constructor(private api: ApiService, private customer: CustomerService, private router: Router) {
  }


  tryLogin() {
    this.api.login(
      this.email,
      this.password
    )
      .subscribe(
        result => {
          if (result.token) {
            this.customer.setToken(result.token);
            this.router.navigateByUrl('/dashboard');
          }
        },
        result => {
          alert(result.error.error);
        });
  }

}

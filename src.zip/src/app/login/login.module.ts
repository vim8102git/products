import { NgModule } from '@angular/core';
import { LoginComponent } from './containers/login/login.component';
import { FormsModule } from '@angular/forms';
import { LoginService } from './login.service';
import { TokenService } from '../auth.token.service';

@NgModule({
    imports: [ FormsModule ],
    declarations: [
        LoginComponent
    ],
    exports: [
        LoginComponent
    ],
    providers:[
        LoginService,
        TokenService
    ]
  })
  export class LoginModule {
  }
import { NgModule} from '@angular/core';
import { HttpModule } from '@angular/http';
import { ApiService } from './api.service';
import { CustomerService } from './customer.service';



@NgModule({
    imports: [
      HttpModule
    ],
    declarations: [],
    providers: [
      ApiService,
      CustomerService
      
    ],
    exports: []
  })
  export class ServicesModule {
  }
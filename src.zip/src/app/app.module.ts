import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

import { ServiceWorkerModule } from '@angular/service-worker';


import { environment } from '../environments/environment';
import { AppComponent } from './app.component';


//Custom modules can be declared here
import { LoginModule } from './login/login.module';
import { ChannelsModule } from './channels/channels.module';

//Custom components can be declared here
import { LoginComponent } from './login/containers/login/login.component';
import { ChannelsComponent } from './channels/containers/channels/channels.component';
import { RouterModule, Routes } from '@angular/router';

//Custom services can be declared here
import {AuthGuard} from './auth.guard';

const routes:Routes = [
  {
    path:'', component:LoginComponent
  },
  {
    path: 'dashboard', component: ChannelsComponent, canActivate: [AuthGuard]
  },
  {
    path: 'login', component: LoginComponent
  }
];

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    ServiceWorkerModule.register('/ngsw-worker.js', { enabled: environment.production }),
    HttpClientModule,
    FormsModule,
    //Custom modules can be injected here
    ChannelsModule,
    LoginModule,
    RouterModule.forRoot(routes)

    
  ],
  providers: [
    AuthGuard
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }

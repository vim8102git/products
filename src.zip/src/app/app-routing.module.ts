import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { ChannelsComponent } from './channels/containers/channels/channels.component';
import {AuthGuard} from './auth.guard';

const appRoutes: Routes = [
  {
    path:'',
    component:LoginComponent
  },
  {
    path: 'dashboard',
    component: ChannelsComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'login',
    component: LoginComponent
  },
];

@NgModule({
    imports: [
      RouterModule.forRoot(appRoutes)
    ],
    exports: [
      RouterModule
    ],
    providers: [
        AuthGuard
      ]
  })
  export class AppRoutingModule {
  }
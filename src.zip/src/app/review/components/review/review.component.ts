import { Component } from '@angular/core';

@Component({
    selector: 'review',
    template:`
        Review component
        <a routerLink="/dashboard">Edit</a>
    `
})
export class ReviewComponent{}
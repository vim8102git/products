import { Component, Output, EventEmitter, Input, ChangeDetectionStrategy } from '@angular/core';
import { Router } from '@angular/router';

import { User } from '../../../auth/shared/services/auth/auth.service';
import { AuthService } from '../../../auth/shared/services/auth/auth.service';

@Component({
    selector: 'app-header',
    changeDetection: ChangeDetectionStrategy.OnPush,
    template: `
    <button (click)="logoutUser()" *ngIf="user?.authenticated">
    Logout 
    </button>
    {{user | json}}
    `
})
export class AppHeaderComponent{
    @Input()
    user: User;

    @Output()
    logout = new EventEmitter<any>();

    logoutUser(){
        this.logout.emit();
    }
    constructor(private authService: AuthService, private router:Router){}

    
}
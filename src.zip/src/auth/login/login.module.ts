import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';

import { AuthFormModule } from '../shared/shared.module';

import { LoginComponent } from './containers/login/login.component';

export const ROUTES:Routes = [
    { path: '', component: LoginComponent}
];
@NgModule({
    imports: [
        CommonModule,
        RouterModule.forChild(ROUTES),
        AuthFormModule
    ],
    declarations: [
        LoginComponent
    ]
})

export class LoginModule{

}
import { Component, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
    selector: 'auth-form',
    template: `
        <form [formGroup]="form" (ngSubmit)="onSubmit()">
            <div>
                <ng-content select="h1"></ng-content>
            </div>
            <label>
                <input type="text" placeHolder="Enter email address" formControlName="email">
            </label>
            <label>
                <input type="password" placeHolder="Enter password" formControlName="password">
            </label>
            <div>
                <ng-content select="button"></ng-content>
            </div>
            <div>
                <ng-content select="a"></ng-content>
            </div>
            <div *ngIf="passwordInvalid">
                Password is required
            </div>
            <div *ngIf="emailInvalid">
                Invalid email
            </div>

        </form>
    `
})

export class AuthFormComponent{

    @Output()
    submitted = new EventEmitter<any>();

    form = this.fb.group({
        email: ['', Validators.email],
        password: ['', Validators.required]
    })
    constructor(private fb: FormBuilder){

    }
    onSubmit(){
        if(this.form.valid){
            this.submitted.emit(this.form);
        }
    }

    get passwordInvalid(){
        const control = this.form.get('password');
        return control.hasError('required') && control.touched;
    }

    get emailInvalid(){
        const control = this.form.get('email');
        return control.hasError('email') && control.touched;
    }
    
}
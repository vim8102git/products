import { Component, OnInit } from '@angular/core';
import { Channel } from '../../models/channel.interface';
import { ChannelsService } from '../../channels.service';

@Component({
    selector: 'channels',
    styleUrls: ['channels.component.scss'],
    template: `
        <div class="container">
            <channel 
                *ngFor="let channel of channels;"
                [channel]="channel">
            </channel>
        </div>
        
    `
})

export class ChannelsComponent implements OnInit{
    channels: Channel[];
    constructor(private channelsService: ChannelsService){}
    ngOnInit(){
        this.channelsService.getAllChannels().subscribe((data: any) =>{
            console.log(data);
        })
    }
}
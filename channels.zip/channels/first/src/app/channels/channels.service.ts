import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Channel } from './models/channel.interface';


const CHANNELS_API: string = '/api/channels';

@Injectable()
export class ChannelsService{
    constructor(private http: HttpClient){}
    getAllChannels(): Observable<any>{
        return this.http.get(CHANNELS_API);

        /*return [{
            "cliccId": "106041",
            "nameEn": "4K Movies",
        },{
            "cliccId": "106041",
            "nameEn": "4K Movies",
        },{
            "cliccId": "106041",
            "nameEn": "4K Movies",
        }]   */  
    }
}
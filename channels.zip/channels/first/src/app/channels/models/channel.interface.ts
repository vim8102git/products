export interface Channel{
    cliccId: string,
    nameEn: string
}
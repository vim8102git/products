import { Component, Input } from '@angular/core';

import { Channel } from '../../models/channel.interface';

@Component({
    selector: 'channel',
    styleUrls: ['channel.component.scss'],
    template: `
    <div class="channel">
        <div class="channel-logo"></div>
        <div class="check-wrap"></div>
        <div class="channel-name">{{channel.nameEn}}</div>
    </div>`
})

export class ChannelComponent{
    @Input()
    channel: Channel;
    constructor(){}
}